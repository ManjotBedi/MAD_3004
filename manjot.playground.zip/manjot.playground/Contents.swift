//: Playground - noun: a place where people can play

import UIKit
var friends : [String]
friends = ["Ishav", "Param", "RinkuDevi", "LA Baburao"]
print ("Friends: \(friends)")
for frnd in friends {
    print ("Friends:\(frnd)")
}

for itr in 0..<friends.count{
    print("Friend \(friends[itr])")
}
for(index, value) in friends.enumerated(){
    print("index:\(index) value: \(value)")
}
for frnd in friends[2...]{
    print("friends:\(frnd)")
}
for frnd in friends[...2]{
    print ("friends: \(frnd)")
}

var num = Array(repeating: 2, count: 4)
print("numbers:\(num)")
num[2] = 100
var more = Array(repeating: 0, count: 3)
print("more:\(more)")
var all = num + more
print("all:\(all)")
for (index ,  value) in all.enumerated()
{
    print ("index:\(index) value: \(value)")
}
print ("all[9] \(all[3])")
var grocery = ["eggs", "milk"]
print("Grocery: \(grocery)")
grocery.append("Rice")
grocery += ["Juice", "Sher aata"]
grocery[1...3] = ["butter","snacks", "icecream"]
print("Grocery: \(grocery)")
grocery.insert("Veggies", at: 4)
grocery.remove(at:3)
grocery.removeLast()
print("Grocery: \(grocery)")
grocery.removeAll()
if grocery.isEmpty{
    print("no grocery")
}
else {
    print("grocery list:\(grocery)")
}
var dynamic = [Any]()
dynamic.append("MB")
dynamic.append(9999)
dynamic.append(90.02)
dynamic.append("f")
print("Dynamic: \(dynamic)")

